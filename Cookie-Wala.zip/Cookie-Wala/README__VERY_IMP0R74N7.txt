CookieWala 
========================

Description
--------------
Be a CookieWala Babu


Source Code and other CSS JS and HTML attributes have been taken from other sources using GNU General Public License. 
We have mentioned RESPECTIVE DEVELOPERS FROM TIME TO TIME..........................................................


Cookiewala is a made-in-roorkee cookie manager . You can add, delete, edit, search, protect, and block cookies!

COURTSEY --> Inspired by many Chrome Based cookie managers.

1.  Delete / Edit / Add / Search Cookie 
2.  Protect a cookie by making it read-only
3.  Block cookies by cookie filter
4.  Import cookies in JSON

]

How to Install
--------------
Turn Dev mode on on your browser (u must know that ;p)
